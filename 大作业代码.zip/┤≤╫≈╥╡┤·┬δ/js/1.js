function popup() {   //检查cookie,隐藏通知栏，并设置cookie,
    var oPopup = document.getElementById('no-attention');   //导航条的那个div
    var oBtn = document.getElementById('not-care');   //获得不再点击的那个p元素
    // num = 0;
    
    if ( getCookie('Off') ) {    
        oPopup.style.display = 'none';
    }
    else{
    oBtn.onclick = function () {
        oPopup.style.display = 'none';
        setCookie("Off", true, 36500 ); 
        };
    }
}
popup();


function setCookie (key, value, t) {  //设置cookie
    var oDate = new Date();
    oDate.setDate( oDate.getDate() + t);
    document.cookie = key + '=' + value + ';expires=' + oDate.toGMTString();
}

function getCookie (key) {  //获取cookie
    var arr1 = document.cookie.split('; ');
    // var arr1 = ["Off=true"];
    for (var i = 0; i < arr1.length; i++) {
        var arr2 = arr1[i].split('=');
        if(arr2[0] == key ){
            return decodeURI(arr2[1]);
        }
    }
}

function removeCookie (key) {  //  删除cookie
	setCookie(key,'',-1);	
}



function serialize (data) {  // 设置参数
    if (!data) return '';
    var pairs = [];
    for (var name in data){
        if (!data.hasOwnProperty(name)) continue;
        if (typeof data[name] === 'function') continue;
        var value = data[name].toString();
        name = encodeURIComponent(name);
        value = encodeURIComponent(value);
        pairs.push(name + '=' + value);
    }
    return pairs.join('&');
}
 
function get(url,options,callback){  //get方法
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function (){
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                 callback(xhr.responseText);
            } else {
                alert("request failed : " + xhr.status);
            }
        }
    };
    xhr.open("get",url + "?" + serialize(options),true);
    xhr.send(null);
}

function getElementsByClassName(element, names) {   //获取class元素
		if (element.getElementsByClassName) {
			return element.getElementsByClassName(names);
		} else {
			var elements = element.getElementsByTagName('*');
			var result = [];
			var element,
				classNameStr,
				flag;
			names = names.split(' ');
			for (var i = 0; element = elements[i]; i++) {
				classNameStr = ' ' + element.className + ' ';
				flag = true;
				for (var j = 0, name; name = names[j]; j++) {
					if (classNameStr.indexOf(' ' + name + '') == -1) {
						flag = false;
						break;
					}
				}
				if (flag) {
					result.push(element);
				}
			}
			return result;
		}
	}


function slide(){    //轮播
    var oBanner = document.getElementById("body-top-photo");
    var oLink = oBanner.getElementsByTagName('a')[0];
    var oImg = oBanner.getElementsByTagName('img')[0];
    var oUl = oBanner.getElementsByTagName('ul')[0];
	var aLi = oBanner.getElementsByTagName('li');
    var data = [
        { link: 'http://open.163.com/' , src : 'image/banner1.jpg' },
        { link: 'http://study.163.com/' , src : 'image/banner2.jpg' },
        { link: 'http://www.icourse163.org/' , src : 'image/banner3.jpg' }
    ];
		
    for (var i = 0; i < data.length; i++) { //初始化
        var oLi = document.createElement('li');
        var aNum = document.createTextNode(i+1);
		var num = 0;
        oUl.appendChild(oLi);  //把新建的li接到ul那里去
        oLi.appendChild(aNum); //把li里面的值附上
        oLink.href = data[0].link;  //第一个a标签的地址
        oImg.src = data[0].src;    //第一个img标签的图片路径
		aLi[0].className = 'active';  //只把aLi中的第一个类名放在active中

		//初始化结束
		aLi[i].index = i;  //第i个li的索引是i
		aLi[i].onclick =function(){   //控制点函数，点那个点会跳转到那个图片
			num = this.index;
			slideshow(this.index);
		};
	}


	var oWindow = document.body.clientWidth;
	oUl.style.left = ( oWindow -  20 * aLi.length)/2 + 'px';
	window.onresize = function(){ 
		oWindow = parseFloat(document.body.clientWidth);
		oUl.style.left = ( oWindow -  20 * aLi.length)/2 + 'px';
	};
	
	function slideshow(index){   //轮播函数
		oImg.style.opacity = 0;
		oImg.style.transition = '';	
		for (var i = 0; i < aLi.length; i++) {
				aLi[i].className = '';
			}
		oLink.href = data[index].link;
		oImg.src = data[index].src;
		aLi[index].className = 'active';
		setTimeout( function  () {
			oImg.style.transition = '0.5s';
			oImg.style.opacity = 1;
		},30);
	}
	function autoplay(){   //每5S变化一次
        timer = setInterval(
            function(){
                num = (num+1)%aLi.length;
                slideshow(num);
            },5000);
    }
	oBanner.onmouseover = function(){  //鼠标移入暂停
        clearInterval(timer);
    };
    oBanner.onmouseout = function(){  //鼠标移除恢复
        autoplay();
    };
    autoplay();
}
slide();

//左右tab切换
function tab_right () {
	var nav_1 = document.getElementById("body-lesson-left-nav-1");
	var nav_2 = document.getElementById("body-lesson-left-nav-2");
	var left_content = document.getElementById("body-lesson-left-content");
	var right_content = document.getElementById("body-lesson-right-content");
	nav_1.style.color = "black";
	nav_1.style.backgroundColor = "white";
	nav_2.style.color = "white";
	nav_2.style.backgroundColor = "#39a030";
	left_content.style.display = "none";
	right_content.style.display = "block";
}

function tab_left () {
	var nav_1 = document.getElementById("body-lesson-left-nav-1");
	var nav_2 = document.getElementById("body-lesson-left-nav-2");
	var left_content = document.getElementById("body-lesson-left-content");
	var right_content = document.getElementById("body-lesson-right-content");
	nav_1.style.color = "white";
	nav_1.style.backgroundColor = "#39a030";
	nav_2.style.color = "black";
	nav_2.style.backgroundColor = "white";
	left_content.style.display = "block";
	right_content.style.display = "none";
}

function NetEase_login () {  //登录按钮的点击
	var btn_login = document.getElementById("m-popuplog");
	btn_login.style.display = "block";
}

function close_window() {
	var btn_login = document.getElementById("m-popuplog");
    btn_login.style.display = "none";
}

function btn_login () {
	var account =  document.getElementById("NetEaseAccount");
	var password  = document.getElementById("NetEasePas");
	var m_popuplog = document.getElementById("m-popuplog");
	var attention_input = document.getElementById("attention_input");
	var attentioned = document.getElementById("attentioned");
	var cancel = document.getElementById("cancel");

	var bool1 = (account.value == "studyOnline");
	// alert(bool1);
	var bool2 = (password.value == "study.163.com");

	if (bool2 && bool1) {
       m_popuplog.style.display = "none";
       attention_input.style.backgroundColor = "#fff";
       attention_input.style.color = "black";
       attentioned.style.width = "110px";
       attention_button.style.width = "110px";
       attention_input.style.width = "110px";
       attention_input.style.textAlign = "left";
       attention_input.disabled = "true";
       cancel.style.display = "block";
       attention_input.style.borderWidth = "1px";
       attention_input.style.borderColor = "#efefef";
       attention_input.style.borderStyle = "solid";
       attention_input.value = "✔ 已关注";
	}
	else{
		alert("账号或密码输入错误");
	};
}

function video_play () {
	var popupvideo = document.getElementById("popupvideo");
	popupvideo.style.display = "block";
}

function clo_video (argument) {
	var popupvideo = document.getElementById("popupvideo");
	popupvideo.style.display = "none";
	var video2 = document.getElementById("video2");
	video2.pause();
}

function getElementsByClassName(element, names) {   
		if (element.getElementsByClassName) {
			return element.getElementsByClassName(names);
		} else {
			var elements = element.getElementsByTagName('*');
			var result = [];
			var element,
				classNameStr,
				flag;
			names = names.split(' ');
			for (var i = 0; element = elements[i]; i++) {
				classNameStr = ' ' + element.className + ' ';
				flag = true;
				for (var j = 0, name; name = names[j]; j++) {
					if (classNameStr.indexOf(' ' + name + '') == -1) {
						flag = false;
						break;
					}
				}
				if (flag) {
					result.push(element);
				}
			}
			return result;
		}
}

//课程详情的浮层
function over (obj) {
	var index = obj.getElementsByTagName("a")[0];
	index.style.display = "block";
}

function out (obj) {
	var index = obj.getElementsByTagName("a")[0];
	index.style.display = "none";
}

function getStyle (obj,attr) {  //获取样式
        if( obj.currentStyle ){
            return obj.currentStyle[attr];
        }
        else{
            return getComputedStyle(obj)[attr];
        }
    }

function change(){  //热门列表滚动
	var oList = document.getElementById("body-lesson-right");
	var oListwrap = getElementsByClassName(oList, 'lesson_all');
	var oListbox = getElementsByClassName(oList, 'lesson_view');
	var timer;
		function autoplay(){
		timer = setInterval(function(){
			if( oListwrap[0].style.top == '-700px'){
				oListwrap[0].style.top = 0;
			}
			else{
				oListwrap[0].style.top = parseFloat(getStyle(oListwrap[0],'top')) - 70 + 'px';
				}
		},5000);
		}
		autoplay();
	oListbox[0].onmouseover = function(){
		clearInterval( timer );
		};
	oListbox[0].onmouseout = function(){
		autoplay();
		};
}
change();